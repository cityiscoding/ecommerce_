<?php return array('dependencies' => array('react', 'wp-api-fetch', 'wp-hooks'), 'version' => 'eaa14a13bf2a5c8492db');
