<?php return array('dependencies' => array('wc-tracks'), 'version' => 'b533123131cfec5b2fac');
